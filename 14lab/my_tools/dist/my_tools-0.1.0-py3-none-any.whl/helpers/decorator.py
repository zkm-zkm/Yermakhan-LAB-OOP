def wrap(text, left="[", right="]"):
    """Wrap text between symbols."""
    return f"{left}{text}{right}"
